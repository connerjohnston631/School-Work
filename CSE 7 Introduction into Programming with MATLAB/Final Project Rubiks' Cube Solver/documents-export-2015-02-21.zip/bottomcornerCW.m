%rotates bottom corner CW
frontrightCW;
topCW;
frontrightCCW;
topCCW;
frontrightCW;
topCW;
frontrightCCW;
topCCW;