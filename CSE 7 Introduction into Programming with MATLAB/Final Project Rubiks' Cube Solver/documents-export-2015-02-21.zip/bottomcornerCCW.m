%rotates bottom corner CCW
frontleftCCW;
topCCW;
frontleftCW;
topCW;
frontleftCCW;
topCCW;
frontleftCW;
topCW;